IONE YOUNG WEBSITE UPLOAD INSTRUCTIONS

This folder is a full Vite + React website for:
- Sleepwalker Universal Never Ending Book Series
- Manifestation Collection
- Sleepwalker merch
- Manifestation merch
- Amazon buttons under all 18 books

EVERY Amazon button points to:
https://www.amazon.com/author/iownssleepwalkerworld2

HOW TO UPLOAD TO GITHUB FROM YOUR PHONE OR COMPUTER:

OPTION 1: Upload through GitHub website
1. Open your GitHub repo:
   https://github.com/ioneyoung23/sleepwalker-world3
2. Click "Add file"
3. Click "Upload files"
4. Open this zip folder on your device.
5. Upload these files/folders into the repo:
   - package.json
   - index.html
   - vite.config.js
   - src folder
   - public folder
6. When GitHub asks for a commit message, type:
   Full website rebuild with books merch and Amazon buttons
7. Click "Commit changes"
8. Vercel should automatically redeploy the website.
9. Wait 1-3 minutes, then check:
   https://sleepwalker-world3.vercel.app/

OPTION 2: Replace everything cleanly
If GitHub gives you problems because files already exist:
1. Open the repo.
2. Delete the old src folder if it exists.
3. Delete the old public folder if it exists.
4. Upload the new src and public folders from this package.
5. Replace package.json, index.html, and vite.config.js.
6. Commit changes.

WHAT IS INCLUDED:
- 9 Sleepwalker book image cards
- 9 Manifestation Collection book image cards
- Amazon button under every book
- Sleepwalker merch section
- Manifestation merch section
- Mobile responsive design
- Black/gold Sleepwalker branding
- Black/orange Manifestation branding

IMPORTANT:
Do not rename the image folders unless you also update src/main.jsx.
