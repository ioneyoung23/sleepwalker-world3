import React from 'react'
import { createRoot } from 'react-dom/client'
import { ExternalLink, BookOpen, ShoppingBag, Sparkles, Crown } from 'lucide-react'
import './styles.css'

const amazonLink = 'https://www.amazon.com/author/iownssleepwalkerworld2'
const websiteLink = 'https://sleepwalker-world3.vercel.app/'

const sleepwalkerBooks = [
  ['Sleepwalker: The Awakening', '/images/sleepwalker/awakening.png'],
  ['Sleepwalker: The Untrusted', '/images/sleepwalker/untrusted.png'],
  ['Sleepwalker: The Untrustworthy', '/images/sleepwalker/untrustworthy.png'],
  ['Sleepwalker: The Unavoidable', '/images/sleepwalker/unavoidable.png'],
  ['Sleepwalker: The Unforgivable', '/images/sleepwalker/unforgivable.png'],
  ['Sleepwalker: The Unattractive', '/images/sleepwalker/unattractive.png'],
  ['Wake Up My Child', '/images/sleepwalker/wake-up-my-child.png'],
  ['Chosen Before Belief', '/images/sleepwalker/chosen-before-belief.png'],
  ['Before We Chose Religion', '/images/sleepwalker/before-we-chose-religion.png'],
]

const manifestBooks = [
  ['What You Feel Is What You Create: Manifestation For Dummies', '/images/manifest/feel-create-dummies.png'],
  ['What You Feel Is What You Create: The Introduction', '/images/manifest/feel-create-introduction.png'],
  ['What You Feel Is What You Create: The Healing Test', '/images/manifest/feel-create-healing-test.png'],
  ['What You Feel Is What You Create: The Reality Test', '/images/manifest/feel-create-reality-test.png'],
  ['What You Accept Is What You Experience', '/images/manifest/accept-experience.png'],
  ['What You Repeat Is What You Remember', '/images/manifest/repeat-remember.png'],
  ['What You Believe Controls What You Receive', '/images/manifest/believe-controls-receive.png'],
  ['What You Ignore Becomes Your Reality', '/images/manifest/ignore-reality.png'],
  ['What You Practice Is What You Become', '/images/manifest/practice-become.png'],
]

const sleepwalkerMerch = [
  ['/images/merch/sleepwalker-merch-products.png', 'Sleepwalker Official Product Collection'],
  ['/images/merch/sleepwalker-merch-products-2.png', 'Sleepwalker Black & Gold Merch'],
  ['/images/merch/sleepwalker-merch-1.png', 'Sleepwalker Merch Catalog'],
  ['/images/merch/sleepwalker-merch-2.png', 'Sleepwalker Apparel & Accessories'],
  ['/images/merch/sleepwalker-merch-3.png', 'Sleepwalker Supreme Voice Merch'],
  ['/images/merch/sleepwalker-merch-4.png', 'Sleepwalker Premium Store'],
  ['/images/merch/sleepwalker-merch-5.png', 'Sleepwalker Gold Storefront'],
]

const manifestMerch = [
  ['/images/merch/manifest-merch-products.png', 'Manifestation Collection Product Catalog'],
  ['/images/merch/manifest-merch-1.png', 'Manifestation Books, Merch & Affirmations'],
  ['/images/merch/manifest-merch-2.png', 'Manifestation Apparel & Accessories'],
]

function AmazonButton({ children = 'Buy on Amazon' }) {
  return <a className="amazonButton" href={amazonLink} target="_blank" rel="noreferrer">{children}<ExternalLink size={17}/></a>
}

function Header() {
  return <header className="siteHeader">
    <a className="brand" href="#home">
      <Crown size={26}/>
      <span>Ione Young</span>
    </a>
    <nav>
      <a href="#sleepwalker">Sleepwalker</a>
      <a href="#manifest">Manifestation</a>
      <a href="#merch">Merch</a>
      <a href="#about">About</a>
      <AmazonButton>Amazon</AmazonButton>
    </nav>
  </header>
}

function Hero() {
  return <section id="home" className="hero">
    <div className="heroText">
      <p className="eyebrow"><Sparkles size={18}/> Official Book & Merch Universe</p>
      <h1>Sleepwalker Universe & Manifestation Collection</h1>
      <p className="heroCopy">Two powerful collections by Ione Young. One awakens the unseen. One heals the emotions that create reality.</p>
      <div className="heroButtons">
        <AmazonButton>Shop All 18 Books on Amazon</AmazonButton>
        <a className="outlineButton" href="#merch">View Official Merch</a>
      </div>
    </div>
    <div className="heroCard">
      <h2>Truth. Awareness. Transformation.</h2>
      <p>All book buttons on this site lead directly to Ione Young’s Amazon Author Page.</p>
      <p className="small">{amazonLink}</p>
    </div>
  </section>
}

function BookGrid({ id, title, subtitle, books, variant }) {
  return <section id={id} className={`section ${variant}`}>
    <div className="sectionTitle">
      <p className="eyebrow">{subtitle}</p>
      <h2>{title}</h2>
    </div>
    <div className="bookGrid">
      {books.map(([name, img]) => <article className="bookCard" key={name}>
        <img src={img} alt={name}/>
        <div className="bookBody">
          <h3>{name}</h3>
          <AmazonButton>Buy Paperback • Hardcover • Ebook</AmazonButton>
        </div>
      </article>)}
    </div>
  </section>
}

function MerchGrid({ title, subtitle, items, variant }) {
  return <div className={`merchBlock ${variant}`}>
    <div className="sectionTitle compact">
      <p className="eyebrow">{subtitle}</p>
      <h2>{title}</h2>
    </div>
    <div className="merchGrid">
      {items.map(([img, name]) => <article className="merchCard" key={name}>
        <img src={img} alt={name}/>
        <h3>{name}</h3>
        <AmazonButton>Shop / Learn More</AmazonButton>
      </article>)}
    </div>
  </div>
}

function About() {
  return <section id="about" className="about">
    <BookOpen size={44}/>
    <h2>About Ione Young’s Collections</h2>
    <p><strong>The Sleepwalker Universal Never Ending Book Series</strong> carries the black, gold, and white spiritual cinematic identity. It is built around awakening, signs, warnings, correction, guidance, and The Supreme Spiritual Power/God moving through people’s lives.</p>
    <p><strong>The Manifestation Collection</strong> carries the black, orange, and white healing identity. It focuses on emotions, beliefs, subconscious programming, patterns, boundaries, awareness, and the reality people create from within.</p>
    <AmazonButton>Visit Ione Young on Amazon</AmazonButton>
  </section>
}

function Footer() {
  return <footer>
    <p>© Ione Young. Sleepwalker Universe & Manifestation Collection.</p>
    <p>{websiteLink}</p>
    <p>Truth. Awareness. Transformation.</p>
  </footer>
}

function App() {
  return <>
    <Header />
    <Hero />
    <BookGrid id="sleepwalker" title="Sleepwalker Universal Never Ending Book Series" subtitle="9 Books • Black Gold White • Supreme Spiritual Power/God’s Voice" books={sleepwalkerBooks} variant="sleepwalker" />
    <BookGrid id="manifest" title="The Manifestation Collection" subtitle="9 Books • Black Orange White • Healing Affirmations" books={manifestBooks} variant="manifest" />
    <section id="merch" className="section merchSection">
      <MerchGrid title="Sleepwalker Official Merchandise" subtitle="Black • Gold • White" items={sleepwalkerMerch} variant="sleepwalker" />
      <MerchGrid title="Manifestation Collection Merchandise" subtitle="Black • Orange • White" items={manifestMerch} variant="manifest" />
    </section>
    <About />
    <Footer />
  </>
}

createRoot(document.getElementById('root')).render(<App />)
